---
layout: page
title: Teaching by Yuchen Yang
---
<div class="cv">
  <b>Brief introduction to R</b>, Every semester <br/> 
Basic Bioinformatics Tools (BBT) Workshops, UNC-CH <br/>
<br/>
